#ifndef _DS18B20_H_
#define _DS18B20_H_
#include "stm32l4xx.h"
#include "delay.h"

#define DS18_GPIO_CLOEN __HAL_RCC_GPIOC_CLK_ENABLE()
#define DS18_GPIO GPIOC
#define DS18_Pin GPIO_PIN_6
#define DS18_Pin_SET DS18_GPIO->BSRR=1<<6
#define DS18_Pin_CLR DS18_GPIO->BSRR=1<<22
#define DS18_Pin_Read HAL_GPIO_ReadPin(DS18_GPIO,DS18_Pin)


uint8_t	temp_data[2]={0x00,0x00},disp_int=0,disp_flo=0,disp_flag='+';

uint8_t DS18_Init()
{
	uint8_t flag=0;
	DS18_GPIO_CLOEN;
	GPIO_InitTypeDef GPIO_InitStruct;	
	GPIO_InitStruct.Mode=GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull=GPIO_NOPULL;
  GPIO_InitStruct.Speed=GPIO_SPEED_HIGH;
	GPIO_InitStruct.Pin=DS18_Pin;
  HAL_GPIO_Init(DS18_GPIO,&GPIO_InitStruct);
	DS18_Pin_SET;
	Delay_us(2);
	DS18_Pin_CLR;
	Delay_us(490);
  DS18_Pin_SET;
	Delay_us(100);

	if(DS18_Pin_Read==0) flag=1;
	else flag=0;
	Delay_us(480);
	DS18_Pin_SET;
	return flag;
}

void WriteByte(uint8_t wr)  //���ֽ�д��
{
	uint8_t i;
	for(i=0;i<8;i++)
	{
		DS18_Pin_CLR;
    Delay_us(2);
		if(wr&0x01)DS18_Pin_SET;
		else DS18_Pin_CLR;
		Delay_us(45);	
		DS18_Pin_SET;
		wr>>=1;
	}
}

uint8_t ReadByte()     //��ȡ���ֽ�
{
	uint8_t i,result=0;
	for(i=0;i<8;i++)
	{		
		DS18_Pin_CLR;
		Delay_us(2);
		result>>=1;
	
		DS18_Pin_SET;	
		Delay_us (4);
		if(DS18_Pin_Read==1)
		result|= 0x80;
		Delay_us(65);
	}
	return(result);
}

uint8_t GetTemp()
{
	uint8_t	flag=0;
	if(DS18_Init()==1)
	{
	WriteByte(0xcc);
	WriteByte(0x44);
	DS18_Init();
	WriteByte(0xcc);
	WriteByte(0xbe);
	temp_data[0]=ReadByte();
	temp_data[1]=ReadByte();
	flag=1;
	}
	return flag;
}

uint8_t Temp_Conv()
{
	uint8_t flag=0;
	if(GetTemp()==1)
	{
	flag=1;
	if(temp_data[1]>0x7f)disp_flag='-';	
	disp_int=((temp_data[0]&0xf0)>>4)|((temp_data[1]&0x0f)<<4);
	disp_flo=temp_data[0]&0x0f;
	disp_flo*=0.625;
	}
	return flag;
}

#endif
